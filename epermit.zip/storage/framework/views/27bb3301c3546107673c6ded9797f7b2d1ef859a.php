<html lang="en">
<head>
    <title>E-Permit</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p>Thank You</p>
</body>
</html><?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views\emails\myTestMail.blade.php ENDPATH**/ ?>