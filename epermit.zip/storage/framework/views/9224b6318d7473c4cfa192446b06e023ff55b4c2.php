<?php $__env->startComponent('mail::message'); ?>
# Introduction

The body of your message.


<?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views/emails/welcome.blade.php ENDPATH**/ ?>